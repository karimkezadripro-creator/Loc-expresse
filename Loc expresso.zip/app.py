from flask import Flask, render_template, request, redirect, url_for, session
import stripe

app = Flask(__name__)
app.secret_key = "supersecretkey"

# Stripe keys (mettre vos vraies clés dans Render)
stripe.api_key = "sk_test_your_secret_key"

# Fake database en mémoire
users = {}
cars = [
    {"id": 1, "name": "Peugeot 208", "price": 50},
    {"id": 2, "name": "Renault Clio", "price": 55},
]

@app.route("/")
def home():
    return render_template("index.html", cars=cars)

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]
        users[email] = password
        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]
        if users.get(email) == password:
            session["user"] = email
            return redirect(url_for("home"))
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect(url_for("home"))

@app.route("/checkout/<int:car_id>", methods=["GET", "POST"])
def checkout(car_id):
    car = next((c for c in cars if c["id"] == car_id), None)
    if not car:
        return "Voiture non trouvée", 404

    if request.method == "POST":
        # Paiement Stripe
        amount = int(car["price"] * 100)
        customer = stripe.Customer.create(
            email=session.get("user", "client@test.com"),
            source=request.form["stripeToken"]
        )
        stripe.Charge.create(
            customer=customer.id,
            amount=amount,
            currency="eur",
            description=f"Location {car['name']}"
        )
        return "Paiement réussi ! Merci pour votre location."

    return render_template("checkout.html", car=car)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
